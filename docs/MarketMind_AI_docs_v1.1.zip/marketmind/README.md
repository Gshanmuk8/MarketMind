# MarketMind AI — Product Specification

**AI Strategic Intelligence Platform.** Not a dashboard, not a tracker — a standing analyst that helps founders decide what to build, what to ignore, and what to do next.

## Reading order

Start with `docs/00_PRODUCT_MANIFESTO.md`, then `01` and `02`. Everything else is a subsystem of those three.

| Range | Layer |
|---|---|
| 00–04 | Why & who — manifesto, vision, PRD, personas, journeys |
| 05–07 | What — functional/non-functional requirements, information architecture |
| 08–10 | Core architecture — system, database, AI |
| 11–16 | Engines — discovery, collection, analysis, reports, notifications, search |
| 17–19 | Experience — UX system, design tokens, components |
| 20–26 | Engineering — API, security, performance, deployment, testing, roadmap, standards |
| 27–29 | Truth — data source catalog (allow-list), decision log (ADRs), honest MVP limitations |
| 30 | Decision Workspace — where intelligence becomes action (Rev. 1.1) |

## Binding rules

1. `00_PRODUCT_MANIFESTO.md` overrides everything. The one test: *does this help the founder make a better decision?*
2. `27_DATA_SOURCE_CATALOG.md` is the runtime allow-list — no source is fetched that isn't cataloged with a legal basis.
3. `28_PRODUCT_DECISIONS.md` is append-only; contradicting an ADR requires superseding it explicitly.
4. `29_MVP_LIMITATIONS.md` is kept current — honesty about coverage is a product feature, not a disclaimer.

## MVP constraints (binding)

Free tiers wherever possible · open/public data first · robots.txt and ToS enforced in code · paid APIs pluggable without refactoring · portfolio quality first, scale after validation.
