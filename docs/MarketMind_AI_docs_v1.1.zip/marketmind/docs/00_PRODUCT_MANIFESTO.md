# 00 — Product Manifesto

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Product |
| **Last updated** | 2026-07-04 |
| **Inherited by** | Every document in this set (01–29) |

---

MarketMind AI is not a dashboard. It is not a tracker. It is not an analytics platform.

**MarketMind AI is an AI Strategic Intelligence Platform.** Its purpose is not to show founders information. Its purpose is to help founders make better strategic decisions.

## The one test

Every feature, screen, schema field, and prompt must pass a single test:

> **Does this help the founder decide what to build, what to ignore, and what to do next?**

If it cannot answer that question, it does not ship. It is simplified or removed.

## The problem we exist to remove

Founders drown in tabs — GitHub, Product Hunt, Reddit, X, blogs, docs, pricing pages, release notes, AI announcements, hiring pages. By the time they finish reading, the information is stale. They do not need more information. They need someone who reads everything and answers:

1. **What changed?**
2. **Why does it matter?**
3. **Should I care?**
4. **What should I do?**

MarketMind AI is that analyst — standing, always-on, and honest about what it knows versus what it infers. And it does not stop at answers: every recommendation ends in a decision the founder can take in one click — save it, roadmap it, or ignore it — so the product changes what people *do*, not just what they read.

## Non-negotiable beliefs

1. **Recommendation over raw data.** Raw feeds are a fallback view, never the default. Every surfaced signal answers "so what" before "what."
2. **Trust through epistemic honesty.** Every insight is labeled: **Verified Public Information**, **AI Inference**, or **Reasoned Recommendation**. Speculation is never presented as fact.
3. **Zero-effort by default.** One input — the user's website URL. Everything else is discovered, not configured. Configuration exists, layered on good defaults.
4. **Signal-to-noise is the product.** Success is showing the 5 things that mattered, not the 500 things we collected.
5. **Respect the web.** Public, non-authenticated sources only. robots.txt and terms of service are enforced in code, not policy.
6. **Free-core, paid-enhanced.** The complete loop works on free/public data and free-tier infrastructure. Paid providers plug in behind interfaces without refactoring.

## What we refuse to be

- A generic scraper or data broker.
- A real-time trading/sentiment tool. Our timescale is days and weeks.
- A CRM.
- A substitute for legal or IP diligence.
- An autonomous decision-maker. Every recommendation is advisory. The product never acts on the user's behalf.

## Long-term direction

MarketMind AI becomes to strategic decisions what Copilot is to code: the first tab a founder opens each morning — not because it tells them everything, but because it tells them **exactly what matters**.
