# 01 — Product Vision

| | |
|---|---|
| **Status** | Approved (Rev. 2 — amended per Vision Review and MVP constraints) |
| **Owner** | Product, Architecture, AI Engineering |
| **Depends on** | 00_PRODUCT_MANIFESTO |

---

## 1. Mission

> MarketMind AI understands a company from nothing more than its website, automatically discovers its real competitors, continuously monitors the public signals that matter, interprets what those signals mean for *this* company, and converts that interpretation into specific, scheduled, decision-ready recommendations.

Four verbs, each mapping to a subsystem:

| Verb | Subsystem | Document |
|---|---|---|
| **Understand** | Company Understanding Engine | 11 |
| **Discover** | Competitor Discovery Engine | 11 |
| **Monitor** | Signal Collection Engine | 12 |
| **Interpret → Recommend** | Analysis + Report Engines | 13, 14 |
| **Decide** | Decision Workspace | 30 |

A proposed feature that serves none of these verbs is scope creep → route to 25_ROADMAP (future) instead of building.

## 2. MVP constraints (binding on all documents)

1. Runs on **free tiers** wherever possible.
2. **Open/public data sources first**; paid data is an optional enhancement, never a dependency.
3. **robots.txt and ToS respected**, enforced in the fetch layer (see 12, 21).
4. Architecture allows **paid APIs to be added later without major refactoring** (provider interfaces — see 08, 10, 28).
5. Built for **learning, demonstration, and portfolio quality first**; scale optimization is deferred until user interest is validated.

## 3. The three-year picture

The durable asset is **not** the breadth of collected data (commoditizes) and **not** the reasoning layer alone (rented from model providers). The durable assets are:

1. **Proprietary longitudinal signal history** per competitor — compounds with time, cannot be backfilled by late entrants (bootstrapped at day one via Wayback Machine backfill — see 12).
2. **The feedback flywheel** — user judgments ("this mattered / this didn't") tune significance thresholds per segment.
3. **Purpose-built compliant collectors** for the signal categories that survive ToS reality.

## 4. Target users (detail in 03)

- **Solo / early-stage founder** — primary. The wedge persona: zero-friction, zero-upkeep, price-sensitive.
- **Product manager at a growth-stage company** — primary for exports/reports; the future monetization anchor.
- **Investor / analyst** — secondary; bursty, on-demand analysis flows.

Explicit non-targets: enterprise CI teams with dedicated analysts; agencies running CI for many clients.

## 5. Core value proposition

> "Tell us your website. We'll tell you who's coming for you, what they're doing, and what to do about it — on your schedule, without you lifting a finger."

Four moments that must each feel effortless (quality bars in 11, 12, 13, 14):

1. **Onboarding** — URL in → company understood → credible ranked competitor list with reasoning, in minutes.
2. **Baseline** — an immediate snapshot intelligence report (not a change report) so day one has value.
3. **Monitoring** — signals accumulate silently and correctly.
4. **Insight & Action** — a small number of things that matter, each with a visible reasoning chain (Signal → Impact → Reason → Recommendation) and evidence label.
5. **Decision** — every recommendation carries one-click actions (Save as Opportunity · Ignore · Create Feature · Add to Roadmap · Review Later) so the product changes what the founder *does*, not just what they read (30).

## 6. Verified vs. inferred: the product-wide contract

Three labels, enforced in schema (09), API (20), UI (17), and prompts (10):

- **Verified Public Information** — directly observed from a primary source, with URL + timestamp.
- **AI Inference** — a conclusion drawn by combining observations.
- **Reasoned Recommendation** — advisory guidance derived from inferences.

The UI must never render an inference with the same visual weight as a verified fact.

## 7. Success metrics

**MVP North Star:** end-to-end demo quality on 5–10 real companies — a complete, honest, compliant loop — plus legibility of the architecture to a technical reviewer.

**Post-validation North Star:** Weekly Actioned Insights per Active Account.

Supporting: discovery acceptance rate; time-to-first-insight; report engagement; user-reported false-positive rate; churn correlated with monitoring gaps (requires collection-health telemetry from day one — see 22).

## 8. Known deferrals (deliberate, per MVP constraints)

Moat commercialization, persona monetization, and per-account COGS modeling are deferred until validation. See 29_MVP_LIMITATIONS for the complete honest list.
