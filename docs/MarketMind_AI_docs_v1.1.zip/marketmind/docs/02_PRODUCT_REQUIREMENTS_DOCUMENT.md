# 02 — Product Requirements Document

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Product |
| **Depends on** | 00, 01 |

---

## 1. Scope model

| Phase | Definition |
|---|---|
| **V1 (MVP)** | Free-tier, public-data, portfolio-grade. Complete loop for the three A-grade signal categories. |
| **V2** | Paid-provider slots activated (funding, firmographics, reviews), team features, more channels. |
| **V3** | Feedback-trained significance models, multi-language, integrations (Slack/CRM), API for customers. |

## 2. V1 feature set

### 2.1 Onboarding & understanding
- Sign in (email magic link or GitHub OAuth). No multi-step onboarding wizard.
- Single required input: company website URL.
- **Company Understanding Engine** extracts: industry, business model, target audience, products, features, pricing, technology, keywords, value proposition, customer segment, company size, market positioning. All fields user-editable afterwards.

### 2.2 Competitor discovery
- Automatic discovery from public information + AI reasoning. No manual searching required.
- Each candidate carries a **confidence score** and visible reasoning ("why we think this is a competitor").
- User can accept, reject, or manually add competitors. Target: ≥70% acceptance rate on suggestions for well-documented SaaS.

### 2.3 Baseline intelligence report (day one)
Snapshot, not change report. Sections: market overview, competitor overview, technology comparison, pricing comparison, feature comparison, AI adoption, engineering activity, hiring trends, customer sentiment (where compliant sources exist), SWOT, threat level, opportunity areas, missing features, strategic recommendations. Historical depth via Wayback backfill (12).

### 2.4 Continuous monitoring (V1 signal categories)
| Category | V1 status |
|---|---|
| Website / product / pricing changes | **Full** |
| Hiring signals (public ATS boards + careers pages) | **Full** |
| Blog / content / release notes | **Full** |
| Engineering activity (GitHub public) | **Full** |
| Funding / business news (free news + EDGAR) | **Partial, labeled** |
| Technology ecosystem intelligence (model-provider announcements) | **Full** (blogs/changelogs/status feeds) |
| Customer sentiment | **Narrow slice** (HN Algolia; Reddit within free-tier terms). G2/Capterra excluded (ToS). |
| Verified firmographics | **Excluded** — provider stub visible in UI as "requires data partner" |

### 2.5 Intelligence layer
Every signal passes: Raw Event → Context → Business Impact → Strategic Meaning → Recommendation (13). Raw data is available as a fallback view only.

### 2.6 Reports
Daily Digest, Weekly Strategic Report, Monthly Market Report, Quarterly Competitive Review (14). Every report answers: what happened, what changed, why it matters, what should I do.

### 2.7 Search
Conversational search over collected evidence: "Analyze Notion", "Compare us with Linear", "What pricing changes happened this month?" (16).

### 2.8 Notifications
Email + Telegram in V1; HH:MM-precision scheduling with timezone/DST handling; per-category preferences; priority filtering; smart digest grouping; quiet hours / weekend pause / vacation mode / snooze; critical-override option (15).

### 2.9 Decision Workspace (30)
One-click decision actions on every recommendation; Inbox / Opportunities / Roadmap-lite (Considering → Planned → Building) / append-only Decision log. GitHub Issues export is a visible V2 slot.

### 2.10 Market Timeline
"Show me everything that happened during the last 6 months" — a chronological, filterable view over all signals and insights (per competitor, per category, or whole market), rendered as a month-grouped timeline. Powered directly by the existing `signals`/`insights` time series plus Wayback backfill, so it is deep on day one.

### 2.11 Daily CEO Brief
The Daily Digest is upgraded to a CEO Brief format (14): personalized greeting, yesterday's confirmed events as a checklist, one prioritized Today's Recommendation with market-urgency level and an evidence-derived conviction indicator listing its supporting signal families.

### 2.12 Trust surface
Three-label evidence system rendered distinctly everywhere (17, 18).

## 3. Out of scope for V1
See 29_MVP_LIMITATIONS — the authoritative list. Highlights: no paid data APIs, no autonomous actions, no WhatsApp/Slack/Discord/push, no multi-language, no team seats, no numeric confidence percentages in UI (evidence buckets instead).

## 4. Release criteria (V1 "done")
1. URL → confirmed competitor set in < 10 minutes for a known SaaS.
2. Baseline report generated within 30 minutes of onboarding, containing ≥ 3 genuinely longitudinal facts (Wayback-derived).
3. Seven consecutive days of scheduled collection with zero manual intervention and a visible collection-health log.
4. A weekly digest sent to email and Telegram at the user's configured HH:MM local time.
5. Every insight in every surface carries one of the three evidence labels.
6. Demo script: 5-minute end-to-end run on a company the audience knows.
7. Written coverage post-mortem across 5–10 tracked companies.
8. Decision Workspace round-trip: recommendation → Save as Opportunity → appears on Roadmap-lite → visible in Decision log with full evidence chain.
9. Market Timeline renders ≥ 6 months of history (backfill-powered) for a demo competitor set.
