# 03 — User Personas

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Product |
| **Depends on** | 01 |

---

## P1 — The Solo Founder (Primary, wedge)

**Ravi, 24, technical founder of a 3-person dev-tools startup.**
- Runs competitive analysis in the gaps between everything else. 30+ tabs daily.
- **Needs:** to know what changed, whether it matters, and what to do — in under 5 minutes a day.
- **Will not tolerate:** manual upkeep, configuration ceremony, raw-data firehoses, confident nonsense.
- **Churn trigger:** one wrong "fact" presented without a source; any week the tool requires maintenance.
- **Design consequences:** one-URL onboarding; opinionated defaults; evidence labels; digest over dashboard.

## P2 — The Growth-Stage PM (Primary for reports; future monetization anchor)

**Meera, 31, PM at a Series-B SaaS.**
- Must justify roadmap and pricing decisions to leadership with competitor evidence.
- **Needs:** exportable, presentable, sourced reports; comparison tables; a defensible evidence trail.
- **Design consequences:** report export, citation-per-claim, weekly strategic report shaped for forwarding.

## P3 — The Investor / Analyst (Secondary)

**Arjun, 35, seed-stage investor.**
- Bursty usage: evaluating one company or sector at a time, then dormant.
- **Needs:** on-demand baseline reports and conversational analysis ("Analyze X"), not continuous monitoring.
- **Design consequences:** ad-hoc analysis flows must work without long-lived monitoring setup (16).

## Anti-personas (explicitly not designed for)
- Enterprise CI analysts needing custom taxonomies, battlecards, and workflow admin.
- Agencies operating CI for many client tenants.
- Anyone requiring private/authenticated data collection — the product will never do this.
