# 04 — User Journeys

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Product, Design |
| **Depends on** | 02, 03 |

---

## J1 — Onboarding (target: < 10 minutes to confirmed competitor set)

1. Sign in (magic link / GitHub). No wizard.
2. Enter company URL. Single field, single action.
3. **Understanding step (automated, ~1–2 min):** the system fetches and characterizes the user's own site through the standard collection pipeline. A structured company profile is shown; every field editable.
4. **Discovery step:** ranked competitor candidates appear with confidence + one-line reasoning each. User accepts / rejects / adds. Low-confidence candidates are framed honestly: "2 confident matches, 5 guesses — help us calibrate."
5. **Baseline report** begins generating immediately after confirmation; user is told when it will be ready and on which channel.

## J2 — The daily 5 minutes

1. 08:00 (user-chosen HH:MM, local tz): Daily Digest arrives on chosen channel(s).
2. Digest leads with the AI Strategic Summary (3–5 sentences), then grouped events by category, each with evidence label and "so what."
3. One tap/click opens the insight detail: sources, timeline, related signals, recommendation.
4. User marks 👍 useful / 👎 didn't matter → feeds the significance thresholds (13).

## J3 — The weekly decision

Monday (or user-chosen day): Weekly Strategic Report. Structured for forwarding to a co-founder/leadership: what happened → what changed → why it matters → recommended actions, each action traceable to labeled evidence.

## J4 — Ad-hoc analysis (P3 flow)

User types "Analyze Notion" or "Compare us with Linear" into Search. System returns a structured answer synthesizing stored evidence, clearly separating verified facts from inference (16). If the entity isn't tracked, a one-off analysis runs within quota.

## J5 — Configuring notifications

Settings → Notifications: channels (email/Telegram), HH:MM time picker, frequency, per-category toggles, priority floor, quiet hours, weekend pause, vacation mode, snooze, critical-override toggle. Every control has a sane default; the journey is optional, never required (15).

## J6 — Trust check (the journey that retains users)

User doubts a claim → clicks the evidence label → sees source URL(s), observation timestamp, and whether the claim is observed, corroborated, or inferred. Doubt resolved in one click or the claim is visibly downgraded.
