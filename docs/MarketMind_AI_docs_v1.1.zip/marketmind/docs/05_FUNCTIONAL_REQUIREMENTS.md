# 05 — Functional Requirements

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 02 |

Requirement IDs are stable and referenced by tests (24).

---

## FR-100 Onboarding & Company Understanding
- **FR-101** The system SHALL authenticate via email magic link and GitHub OAuth.
- **FR-102** The system SHALL require exactly one input to begin: a company website URL.
- **FR-103** The Company Understanding Engine SHALL extract: industry, business model, target audience, products, features, pricing, technology, keywords, value proposition, customer segment, company size, market positioning.
- **FR-104** All extracted profile fields SHALL be user-editable and re-derivable on demand.

## FR-200 Competitor Discovery
- **FR-201** The system SHALL propose competitors automatically without user searching.
- **FR-202** Each candidate SHALL carry a confidence score (internal numeric; UI shows bucket) and human-readable reasoning.
- **FR-203** Users SHALL be able to accept, reject, and manually add competitors.
- **FR-204** Rejections SHALL be persisted and excluded from re-suggestion.

## FR-300 Signal Collection
- **FR-301** Collection SHALL occur only from public, non-authenticated sources on the allow-list (27).
- **FR-302** The fetch layer SHALL check robots.txt before every crawl and honor per-domain rate limits (21).
- **FR-303** The system SHALL collect: page/pricing diffs, hiring signals (public ATS JSON + careers pages), blog/release RSS, GitHub public activity, free news/EDGAR business events, model-provider ecosystem announcements.
- **FR-304** The system SHALL backfill historical snapshots via the Wayback Machine CDX API at competitor-add time.
- **FR-305** Every collection run SHALL write a health record (source, status, latency, items) (FR for metric 5 in 01§7).

## FR-400 Intelligence Layer
- **FR-401** Every signal SHALL pass the pipeline Raw Event → Context → Business Impact → Strategic Meaning → Recommendation before user display.
- **FR-402** The system SHALL deduplicate signals across sources prior to interpretation.
- **FR-403** The system SHALL assign significance (critical/high/medium/low) per signal, per tracked company context.
- **FR-404** Every stored insight SHALL carry exactly one evidence label: `verified` | `inference` | `recommendation`.
- **FR-406** Every insight SHALL expose its full reasoning chain — Signal → Impact → Reason → Recommendation — as distinct, user-visible fields; a recommendation without a visible Reason step SHALL fail validation.
- **FR-407** Every recommendation SHALL carry an evidence-derived conviction score with its supporting signal families enumerated (e.g., hiring trend + GitHub activity + documentation updates) per ADR-011.
- **FR-405** The system SHALL record user feedback (useful / didn't matter) per insight.

## FR-500 Reports
- **FR-501** The system SHALL generate a Baseline Intelligence Report after onboarding (sections per 02§2.3).
- **FR-502** The system SHALL generate Daily, Weekly, Monthly, and Quarterly reports per user schedule.
- **FR-503** Every report section SHALL answer: what happened, what changed, why it matters, what to do.
- **FR-504** Reports SHALL be exportable (HTML → PDF in V1).

## FR-600 Search
- **FR-601** The system SHALL answer natural-language queries over stored evidence with labeled claims.
- **FR-602** Search SHALL support entity analysis ("Analyze X") and comparison ("Compare us with Y").

## FR-700 Notifications (full spec: 15)
- **FR-701** Channels: email and Telegram in V1; architecture SHALL support adding WhatsApp/Slack/Discord/push without core changes.
- **FR-702** Delivery time SHALL be user-selectable at HH:MM precision, interpreted in the user's IANA timezone with DST handled.
- **FR-703** Frequencies: daily, weekdays-only, weekly, monthly, instant-critical-only.
- **FR-704** Per-category and per-topic preference toggles SHALL be supported (competitor, technology, engineering, hiring, customer intelligence — itemized per 15§4).
- **FR-705** Priority floor filter: critical-only / high+ / medium+ / everything.
- **FR-706** Related events SHALL be grouped into a single smart digest rather than sent individually.
- **FR-707** Quiet hours, weekend pause, vacation mode, and snooze SHALL be supported; critical alerts MAY override quiet hours only if the user opts in.

## FR-800 Trust
- **FR-801** No UI surface SHALL render an AI inference with the same visual treatment as verified information (17, 18).
- **FR-802** Every claim SHALL be traceable to source URL(s) and observation timestamp in ≤ 1 interaction.

## FR-1000 Decision Workspace (30)
- **FR-1001** Every recommendation and insight SHALL offer: Save as Opportunity, Ignore, Create Feature, Add to Roadmap, Review Later; Export to GitHub Issues SHALL render as a disabled future slot.
- **FR-1002** Decisions SHALL retain full provenance (decision → insight → signals → sources).
- **FR-1003** Roadmap-lite SHALL provide exactly three stages: Considering, Planned, Building.
- **FR-1004** Decision actions SHALL feed the significance/personalization loop (FR-405 extended): saved/created/roadmapped = positive, ignored = negative.
- **FR-1005** A Review Later item SHALL resurface in the CEO Brief on its chosen date.

## FR-1100 Market Timeline
- **FR-1101** The system SHALL render a chronological timeline of signals and insights filterable by competitor, category, significance, and date range.
- **FR-1102** Timeline SHALL be answerable via Search ("show me everything that happened during the last 6 months") returning the same view.
- **FR-1103** Backfilled (Wayback) events SHALL appear on the timeline, visually marked as archive-derived.

## FR-900 Extensibility
- **FR-901** Every signal category and the LLM layer SHALL sit behind a provider interface; paid providers register via configuration (env key present) and degrade gracefully when absent (08, 10, 28/ADR-003).
