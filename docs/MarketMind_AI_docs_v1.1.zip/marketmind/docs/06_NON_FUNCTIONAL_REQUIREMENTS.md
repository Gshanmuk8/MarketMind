# 06 — Non-Functional Requirements

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 01§2 (MVP constraints), 05 |

---

## NFR-1 Cost
- **NFR-1.1** Total recurring infrastructure cost target: **$0/month** on free tiers (23). Any exception requires an ADR (28).
- **NFR-1.2** LLM usage SHALL fit within free-tier daily quotas; quota exhaustion degrades gracefully (defer interpretation, never drop signals) (10).

## NFR-2 Compliance & Ethics
- **NFR-2.1** robots.txt compliance and domain allow-listing enforced in code (21). Zero tolerance: a source that cannot be collected compliantly is not collected.
- **NFR-2.2** No authentication-gated, paywalled, or CAPTCHA-protected content is ever accessed.
- **NFR-2.3** Per-domain politeness: ≤ 1 request/2s default, exponential backoff, identifying User-Agent with contact URL.

## NFR-3 Reliability
- **NFR-3.1** Scheduled collection success rate ≥ 95% per week per source category; failures visible in the health log within one run.
- **NFR-3.2** A dead source SHALL never silently produce "no changes" — it produces a "collection gap" state surfaced in reports.

## NFR-4 Performance (budgets in 22)
- **NFR-4.1** Onboarding: URL → editable company profile ≤ 2 min; → confirmed competitors ≤ 10 min.
- **NFR-4.2** Baseline report ready ≤ 30 min after confirmation.
- **NFR-4.3** Dashboard p95 page load ≤ 2.5s on free-tier hosting.
- **NFR-4.4** Notification delivery within ±5 min of scheduled HH:MM.

## NFR-5 Data
- **NFR-5.1** Storage budget ≤ 0.5 GB (free Postgres): store hashes, extracted text, structured diffs; raw HTML only for latest snapshot per page.
- **NFR-5.2** All signals immutable once written; corrections are new records (auditability).

## NFR-6 Security & Privacy (21)
- **NFR-6.1** Secrets only in environment/secret manager; never in repo.
- **NFR-6.2** User data: email, timezone, preferences, company profile. No collection of user analytics beyond product telemetry; deletable on request.

## NFR-7 Maintainability / Portfolio Quality
- **NFR-7.1** A technical reviewer can trace any UI claim → insight → signal → source URL using only the docs and schema.
- **NFR-7.2** Every provider interface has ≥ 1 free implementation and a documented paid slot.
- **NFR-7.3** Code standards per 26; docs updated in the same PR as behavior changes.

## NFR-8 Timescale honesty
- The product's cadence is hours-to-days, never seconds. No feature may imply real-time guarantees.
