# 07 — Information Architecture

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Design |
| **Depends on** | 02, 04 |

---

## Navigation model

```
MarketMind
├── Today                  ← default view: latest digest, AI strategic summary
├── Competitors
│   ├── [Competitor page]  ← profile, timeline, signals by category, SWOT
│   └── Compare            ← side-by-side (pricing / features / tech / hiring)
├── Intelligence
│   ├── Technology         ← model-provider ecosystem feed (interpreted)
│   ├── Engineering        ← GitHub-derived signals
│   ├── Business           ← funding/news (labeled partial coverage)
│   └── Customers          ← sentiment slice (labeled narrow coverage)
├── Timeline               ← market chronology; filters: competitor / category / range
├── Decisions
│   ├── Inbox              ← undecided recommendations (significance × conviction)
│   ├── Opportunities
│   ├── Roadmap            ← Considering / Planned / Building
│   └── Decision log
├── Reports
│   ├── Baseline
│   ├── Daily / Weekly / Monthly / Quarterly archive
│   └── Export
├── Search                 ← conversational analyst
└── Settings
    ├── Company profile (editable understanding output)
    ├── Competitors (accept/reject/add)
    ├── Notifications (channels, schedule, preferences, quiet hours)
    ├── Data & sources (allow-list visibility, collection health)
    └── Account
```

## Content hierarchy rules

1. **Conclusion first.** Every page leads with interpretation; raw signals live one level down ("Evidence" tab).
2. **Evidence labels are structural**, not decorative — they appear at the claim level, not the page level.
3. **Coverage honesty is IA:** categories with partial/narrow coverage carry a permanent, unobtrusive coverage badge linking to 29's user-facing equivalent.
4. **Empty states teach.** A category with no compliant source for a given competitor states why ("Competitor has no public repos") rather than showing zero.

## URL structure

```
/today
/competitors/:slug
/competitors/compare?a=:slug&b=:slug
/intelligence/:category
/timeline?competitor=&category=&from=&to=
/decisions/:view
/reports/:type/:id
/search?q=
/settings/:section
```
