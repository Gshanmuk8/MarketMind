# 08 — System Architecture

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Architecture |
| **Depends on** | 01§2, 05, 06 |

---

## 1. Shape

Two planes, strictly separated because free-tier serverless functions have short execution ceilings:

- **Interactive plane** — the web app (auth, dashboard, settings, search, report viewing). Serverless, request/response, never runs long jobs.
- **Collection/analysis plane** — scheduled jobs (crawl, diff, interpret, generate, deliver). Runs on GitHub Actions cron (free for public repos); each run is an auditable log.

```
                 ┌────────────────────────────────────────────┐
                 │              INTERACTIVE PLANE             │
  User ────────► │  Next.js app (Vercel Hobby / CF Pages)     │
                 │  Auth · Dashboard · Search · Settings      │
                 └───────────────┬────────────────────────────┘
                                 │ SQL (RLS)
                 ┌───────────────▼────────────────────────────┐
                 │        Postgres (Supabase/Neon free)       │
                 │  companies · competitors · signals ·       │
                 │  insights · reports · schedules · health   │
                 └───────────────▲────────────────────────────┘
                                 │ writes
   ┌─────────────────────────────┴─────────────────────────────┐
   │                 COLLECTION / ANALYSIS PLANE                │
   │              GitHub Actions cron (2×/day + hourly tick)    │
   │                                                            │
   │  Compliance Fetch Layer ── robots.txt · allow-list · rate  │
   │        │                                                   │
   │  Collectors (provider interfaces, one per category)        │
   │   PageDiff · Hiring(ATS) · Blog(RSS) · GitHub · News ·     │
   │   TechEcosystem · Sentiment(HN) · [paid slots: stubs]      │
   │        │                                                   │
   │  Analysis Engine (13): dedupe → context → impact →         │
   │   meaning → recommendation   (InterpretationProvider:      │
   │   Gemini free / Groq free → paid slot)                     │
   │        │                                                   │
   │  Report Engine (14) ──► Notification Engine (15)           │
   │                          Email (Resend) · Telegram Bot     │
   └────────────────────────────────────────────────────────────┘
```

## 2. The provider-interface rule (load-bearing; ADR-003)

One interface **per signal category**, not per vendor:

```ts
interface SignalProvider {
  category: SignalCategory;
  tier: "free" | "paid";
  isConfigured(): boolean;          // env key present?
  collect(target: Competitor, since: Date): Promise<Signal[]>;
}
```

- Registry resolves providers at runtime: paid provider used **iff configured**, else free provider, else explicit `coverage_gap` record. Graceful degradation is therefore the default execution path, exercised daily — not an untested error branch.
- The same pattern wraps LLMs (`InterpretationProvider`, 10) and delivery channels (`DeliveryChannel`, 15).

## 3. Data flow contract

`Signal` is the universal unit (schema in 09): every collector normalizes into it; every downstream stage consumes only it. `source_type` and evidence labeling are set at collection time and never inferred later.

## 4. Scheduling

- **2×/day full collection run** (matches days/weeks product timescale, NFR-8).
- **Hourly tick** for: notification dispatch at users' HH:MM local times (15§3), critical-alert evaluation, retry queue.
- Timezone math is done in the scheduler (UTC storage, IANA tz conversion per user) — see ADR-006.

## 5. Failure philosophy

Every stage writes health records (FR-305). A failed source degrades to a visible gap, never a silent "no news." Retries with backoff; poison entries parked with reason.
