# 09 — Database Architecture

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 08 |

Postgres (Supabase/Neon free tier, ≤ 0.5 GB — NFR-5.1). All timestamps UTC (`timestamptz`). RLS on all user-scoped tables.

---

## Core schema (DDL sketch)

```sql
-- Identity & workspace
create table users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  tz text not null default 'UTC',          -- IANA, drives 15
  created_at timestamptz default now()
);

create table companies (                    -- the user's own company
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users not null,
  url text not null,
  profile jsonb not null,                   -- Understanding Engine output (FR-103), user-editable
  profile_edited_at timestamptz
);

create table competitors (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies not null,
  url text not null,
  name text not null,
  status text not null check (status in ('suggested','accepted','rejected','manual')),
  discovery_confidence numeric,             -- internal only; UI shows buckets
  discovery_reasoning text,
  created_at timestamptz default now()
);

-- Watchable surfaces per competitor (pricing page, blog feed, ATS board, repo…)
create table watch_targets (
  id uuid primary key default gen_random_uuid(),
  competitor_id uuid references competitors not null,
  category text not null,                   -- page_diff|hiring|blog|github|news|tech_ecosystem|sentiment
  locator text not null,                    -- URL / feed / board slug / repo
  provider text not null,                   -- resolved provider id
  active boolean default true
);

-- The universal unit (08§3). Immutable (NFR-5.2).
create table signals (
  id uuid primary key default gen_random_uuid(),
  watch_target_id uuid references watch_targets not null,
  category text not null,
  observed_at timestamptz not null,
  source_url text not null,
  source_type text not null check (source_type in ('observed','corroborated','inferred')),
  content_hash text not null,               -- dedupe + LLM-cache key (10)
  payload jsonb not null,                   -- normalized diff / posting / release / article
  backfilled boolean default false,         -- Wayback-derived
  unique (watch_target_id, content_hash)
);

-- Interpreted output of the Analysis Engine (13)
create table insights (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies not null,
  evidence_label text not null check (evidence_label in ('verified','inference','recommendation')),
  significance text not null check (significance in ('critical','high','medium','low')),
  title text not null,
  so_what text not null,
  reasoning_chain jsonb,                     -- {signal, impact, reason, recommendation} — FR-406
  conviction jsonb,                          -- {score, factors[]} evidence-derived — ADR-011
  recommendation text,
  signal_ids uuid[] not null,               -- provenance (FR-802)
  model_id text,                            -- which InterpretationProvider produced it
  created_at timestamptz default now()
);

create table decisions (                     -- Decision Workspace (30)
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies not null,
  insight_id uuid references insights not null,
  action text not null check (action in
    ('opportunity','ignored','feature','roadmap','review_later')),
  stage text check (stage in ('considering','planned','building')),
  brief text, review_at date, reason text,
  created_at timestamptz default now()
);

create table insight_feedback (
  insight_id uuid references insights,
  user_id uuid references users,
  verdict text check (verdict in ('useful','didnt_matter')),
  created_at timestamptz default now(),
  primary key (insight_id, user_id)
);

create table reports (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies not null,
  type text check (type in ('baseline','daily','weekly','monthly','quarterly')),
  period_start date, period_end date,
  body jsonb not null,                      -- structured sections; rendered by 14/17
  created_at timestamptz default now()
);

-- Notifications (15)
create table notification_settings (
  user_id uuid primary key references users,
  channels jsonb not null default '{"email":true,"telegram":false}',
  send_time time not null default '08:00',  -- HH:MM, interpreted in users.tz
  frequency text not null default 'daily'
    check (frequency in ('daily','weekdays','weekly','monthly','instant_critical')),
  weekly_day int, monthly_day int,
  priority_floor text not null default 'medium'
    check (priority_floor in ('critical','high','medium','all')),
  category_prefs jsonb not null default '{}',  -- per-topic toggles (15§4)
  quiet_hours jsonb,                            -- {"start":"22:00","end":"07:00"}
  weekend_pause boolean default false,
  vacation_until date,
  snooze_until timestamptz,
  critical_overrides_quiet boolean default false
);

create table deliveries (                    -- audit of every send
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users,
  channel text, kind text, report_id uuid,
  scheduled_for timestamptz, sent_at timestamptz,
  status text check (status in ('sent','failed','suppressed_quiet','suppressed_pref'))
);

create table collection_health (             -- FR-305 / NFR-3
  id bigint generated always as identity primary key,
  run_id text not null, watch_target_id uuid,
  status text check (status in ('ok','empty','blocked','error','gap')),
  detail text, latency_ms int, items int,
  created_at timestamptz default now()
);

create table llm_cache (                     -- 10§4: never reinterpret unchanged content
  cache_key text primary key,                -- hash(model, prompt_version, content_hash set)
  output jsonb not null,
  created_at timestamptz default now()
);
```

## Storage discipline
- Raw HTML: latest snapshot only, in object storage if needed; DB stores extracted text + structured diff.
- `signals.payload` capped (8 KB typical) — extraction happens at collection, not later.
- Indexes: `signals(watch_target_id, observed_at desc)`, `insights(company_id, created_at desc)`, `deliveries(user_id, scheduled_for)`.
