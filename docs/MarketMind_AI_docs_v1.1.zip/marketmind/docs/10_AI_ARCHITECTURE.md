# 10 — AI Architecture

| | |
|---|---|
| **Status** | Approved |
| **Owner** | AI Engineering |
| **Depends on** | 08, 09; ADR-003/004/005 (28) |

---

## 1. Provider abstraction

```ts
interface InterpretationProvider {
  id: string;                                // "gemini-free" | "groq-free" | "claude-paid"…
  tier: "free" | "paid";
  limits: { rpm: number; rpd: number; tpm?: number };
  isConfigured(): boolean;
  interpret(batch: SignalBatch, task: TaskSpec): Promise<Interpretation>;
}
```

**V1 cascade:** `gemini-free → groq-free → defer`. Paid slot (`claude-paid` / `gpt-paid`) activates when its key exists — zero code change (FR-901). Failover between the two free providers is implemented and demoed (portfolio requirement, NFR-7.2).

## 2. Quota-shaped design (free tiers make RPM/RPD first-class inputs)

1. **Batch, don't stream:** one run interprets all of a competitor's new signals in a few structured prompts, never one call per signal.
2. **Cache on content:** `llm_cache` keyed on (model, prompt_version, content-hash set). Unchanged content is **never** reinterpreted (09).
3. **Budgeter:** each run gets a token/request budget; ordering = significance-pre-score desc; leftovers defer to the next run with status `deferred`, never dropped (NFR-1.2).

## 3. Task taxonomy (each has a versioned prompt template)

| Task | Input | Output |
|---|---|---|
| `understand_company` | site text | company profile JSON (FR-103) |
| `discover_competitors` | profile + search snippets | candidates + reasoning + confidence |
| `presignificance` | raw signal | cheap 0–1 score (small/free model) — gatekeeper before full interpretation |
| `interpret` | deduped signal batch + both-sides company context | per-signal: context, business impact, strategic meaning, significance, evidence label, recommendation |
| `digest` | period's insights | grouped digest + AI Strategic Summary |
| `report_section` | insights + history | report section JSON (14) |
| `search_answer` | question + retrieved evidence | labeled, cited answer (16) |

## 4. The interpretation contract (the heart — Manifesto §"Philosophy of Intelligence")

Prompts require structured output answering, for every event: *what changed · why it matters · who is affected · how it affects THIS user's company · should the founder care · what to do.* The user's own company profile (from the identical pipeline) is always in context, so recommendations are grounded in **public knowledge of both sides** — never in private data the system doesn't have (ADR-002).

Hard rules enforced by output schema + validator:
- Every claim tagged `verified | inference | recommendation`; verified claims must reference `signal_ids`.
- No numeric confidence in user-facing text — **evidence buckets only**: *observed / corroborated by N sources / single-source inference* (ADR-004: LLM numeric confidence is not calibratable; false precision destroys trust).
- Refuse-to-guess: if evidence is insufficient, output `insufficient_evidence`, which renders as an honest gap, not filler.

## 5. Quality loop

- `insight_feedback` verdicts adjust per-category significance thresholds (simple Bayesian update in V1; learned model is V3).
- Weekly automated audit: sample 10 insights → verify each `verified` claim resolves to its source → mismatches fail CI-style and page the maintainer.
- Prompt templates are versioned files in-repo; every insight records `model_id` + prompt version for reproducibility.

## 6. What the AI layer must never do
Fabricate sources; upgrade an inference to verified; interpret content the compliance layer didn't approve; exceed provider ToS; present a recommendation without its evidence chain.
