# 11 — Company Understanding & Competitor Discovery Engine

| | |
|---|---|
| **Status** | Approved |
| **Owner** | AI Engineering |
| **Depends on** | 10, 12 |

---

## Quality bar (stated up front, per Vision §5 Moment 1)
- Editable company profile ≤ 2 min after URL submission.
- Confirmed competitor set ≤ 10 min.
- Suggestion acceptance target ≥ 70% for well-documented SaaS; below 50% in testing blocks release.

## Stage A — Company Understanding Engine

1. Compliance-fetch the user's site: home, pricing, product, about, docs index, careers, blog feed (same collectors as competitors — symmetry is deliberate, ADR-002).
2. `understand_company` task (10§3) produces the structured profile (industry, business model, audience, products, features, pricing, technology, keywords, value proposition, segment, size, positioning).
3. Render profile for review; every field editable (FR-104). Edits are ground truth thereafter.

## Stage B — Candidate generation (quota-aware)

Signals combined (each cheap, free, compliant):
- **Search:** Google Programmable Search JSON API — 100 free queries/day; discovery uses ≤ 15 per onboarding (e.g., `"<category>" alternatives`, `"vs <company>"`, `<value-prop keywords> tool`). Quota shaping per ADR-005.
- **Comparison-page mining:** competitors named on "vs/alternatives" pages found in search results.
- **Ecosystem adjacency:** shared directories/categories on public listing pages; GitHub topic adjacency where relevant.
- **AI reasoning:** `discover_competitors` task merges evidence → candidates with reasoning + confidence.

## Stage C — Confirmation UX (the human is the analyst's editor)

- Ranked candidates, each with one-line reasoning ("Their pricing page targets the same SMB segment; named on 3 comparison pages").
- Confidence shown as buckets. Honest framing on thin evidence: "2 confident matches, 5 guesses — help us calibrate."
- Accept / reject / add-by-URL. Rejections persist (FR-204). Added competitors run through Stage A understanding automatically.

## Fallback behavior
- Long-tail/novel category with < 3 confident candidates → the system says so and leads with manual-add, rather than padding with noise. An honest short list beats a confident wrong one (Manifesto belief 2).

## Metrics
Acceptance rate, time-to-confirmation, rejection reasons (sampled), and post-hoc "missed competitor" additions in week 1 (a proxy for recall).
