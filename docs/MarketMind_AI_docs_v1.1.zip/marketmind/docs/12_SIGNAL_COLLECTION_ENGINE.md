# 12 — Signal Collection Engine

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 08, 09, 21, 27 |

---

## 1. Compliance Fetch Layer (wraps every request; no bypass path exists)

```
request → allow-list check (27) → robots.txt fetch+cache (24h) → rule evaluation
        → per-domain rate limiter (≥2s spacing, jitter) → fetch (UA with contact URL)
        → on 403/429: exponential backoff, then mark BLOCKED (health record) — never retry-hammer, never spoof
```
Blocked/removed sources become visible `coverage_gap` states (NFR-3.2). This layer is a portfolio showpiece: it logs every decision it makes.

## 2. Collectors (each implements `SignalProvider`, 08§2)

### 2.1 PageDiffCollector — grade A
- Watch targets: pricing, home, product, changelog pages (seeded from sitemap.xml + understanding stage).
- Fetch → extract main text (strip nav/footer) → hash → structured diff vs. last snapshot (added/removed/changed blocks; price tokens parsed specially).
- **Wayback backfill:** at competitor-add, query CDX API for historical snapshots of pricing/home (up to 24 months, ≤ 12 snapshots); diff chronologically; write `backfilled=true` signals. This gives the Baseline Report longitudinal facts on day one (ADR-001).

### 2.2 HiringCollector — grade A
- Detect ATS from careers page: **Greenhouse / Lever / Ashby public JSON board endpoints** (documented, unauthenticated, intended for public consumption) → structured postings (title, team, location, posted_at).
- Fallback: careers-page diff via 2.1.
- Derived series: openings by function over time; new-role events; senior-hire events.

### 2.3 ContentCollector — grade A
- RSS/Atom for blog, changelog, release notes. Feed discovery via `<link rel=alternate>` + common paths. New-entry signals with extracted text.

### 2.4 GitHubCollector — grade B
- REST API, token, 5k req/hr free. Releases, tags, repo creation, stars/forks deltas, top-level dependency-file changes on public repos. Absent public repos → explicit "no public engineering signal" state.

### 2.5 NewsCollector — grade B (labeled partial)
- Google News RSS per competitor name; competitor press pages; **SEC EDGAR full-text search** for Form D/S-1 (US). All outputs labeled; coverage badge "partial" in UI. Paid slot: Crunchbase provider (stub).

### 2.6 TechEcosystemCollector — grade A
- Official blogs/changelogs/status feeds of model providers (OpenAI, Google/Gemini, Anthropic, Groq, Cerebras, OpenRouter, DeepSeek, Mistral, Meta/Llama, xAI, Perplexity — list in 27). Tracks models, pricing, context windows, SDK/API changes, MCP/function-calling/memory/voice/vision/embeddings announcements, deprecations. These are global watch targets shared across all users (collected once).

### 2.7 SentimentCollector — grade C (narrow slice, labeled)
- **HN via Algolia API** (fully open). Reddit only within current free-tier API terms, low rate. **G2/Capterra: excluded — ToS prohibits scraping**; `ReviewSignalProvider` exists as a visible stub ("requires licensed data partner").

### 2.8 Paid stubs (V1 ships the interface, not the vendor)
`FirmographicsProvider`, `ReviewSignalProvider`, `FundingProvider(paid)`, `TechStackProvider(paid)` — each `isConfigured() === false` in V1 and renders as an honest locked slot in Settings → Data & sources.

## 3. Normalization
Every collector emits `Signal` rows (09) with `source_url`, `observed_at`, `source_type='observed'`, `content_hash`, normalized `payload`. Dedup at insert (`unique(watch_target_id, content_hash)`) and again cross-source in 13.

## 4. Scheduling & budget
2×/day full run (08§4). Per-run fetch budget ≈ 40 requests/competitor; ordering: pricing > careers/ATS > blog > GitHub > news > sentiment.
