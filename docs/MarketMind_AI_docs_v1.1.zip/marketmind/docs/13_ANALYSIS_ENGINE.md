# 13 — Analysis Engine (the Intelligence Layer)

| | |
|---|---|
| **Status** | Approved |
| **Owner** | AI Engineering |
| **Depends on** | 10, 12 |

---

## The pipeline (FR-401)

```
Raw Event → Context → Business Impact → Strategic Meaning → Recommendation
```
Raw data is never shown first; it survives only as the Evidence view behind each insight.

## Stage 1 — Dedupe & cluster
Cross-source dedup (same funding round from 3 outlets = one event). Clustering: signals about the same underlying move (price cut + landing-page reframe + sales hiring) merge into one **event cluster** — clusters are where the best insights live.

## Stage 2 — Pre-significance gate
Cheap `presignificance` scoring (10§3) filters noise (typo-level page diffs, boilerplate posts) **before** spending interpretation quota. Threshold per category, adjusted by feedback (Stage 5).

## Stage 3 — Interpretation
`interpret` task with both-sides context (user profile + competitor profile + relevant history). Output per event/cluster:
- **What changed** (verified claims → signal_ids)
- **Why it matters / who is affected** (inference)
- **Impact on this user's company** (inference, grounded in the user's public profile only — ADR-002)
- **Significance:** critical / high / medium / low (drives 15's priority floor)
- **Reasoning chain (FR-406):** the output is structured as Signal → Impact → **Reason** → Recommendation, and the Reason step is rendered to the user — users trust reasoning, not conclusions. A recommendation whose Reason is empty fails validation (Stage 4).
- **Conviction (FR-407 / ADR-011):** each recommendation carries an evidence-derived conviction score computed deterministically from the breadth and agreement of supporting signal *families* (e.g., hiring trend + GitHub activity + documentation updates ⇒ high). The factors are always listed alongside the number — the score is explainable arithmetic over evidence, never the model's self-reported confidence.
- **Recommendation** (labeled `recommendation`; advisory always — Manifesto non-goal)
- Or `insufficient_evidence` → rendered as an honest gap.

Never "OpenAI released a new model." Always: what changed, why it matters, who's affected, how it affects *you*, should you care, what to do.

## Stage 4 — Validation
Schema validation; every `verified` claim must resolve to signal_ids; evidence-label sanity (a claim citing zero signals cannot be `verified`); profanity/PII scrub. Failures re-queue once, then park with reason.

## Stage 5 — Feedback loop
👍/👎 per insight (FR-405) and — much stronger — Decision Workspace actions (FR-1004): saved/created/roadmapped insights raise the weight of their pattern; ignored insights lower it. "Didn't matter"/ignored ×3 on the same pattern suppresses it for that user.

**Personal Intelligence (V2/V3 direction, 25):** the same decision/feedback stream learns per-founder attention — e.g., ignores hiring, loves pricing, always reads OpenAI updates — and reorders digests and Brief priorities accordingly. V1 collects the data; V2 personalizes ranking; V3 learns models per segment.

## Significance rubric (V1 defaults)
| Level | Examples |
|---|---|
| **Critical** | Direct-competitor pricing change; competitor launches feature matching user's core value prop; acquisition of/by a competitor |
| **High** | Major model-provider pricing/capability change relevant to user's stack; competitor senior hire in user's domain; funding event |
| **Medium** | Notable release cadence shift; sustained hiring in one function; significant content pivot |
| **Low** | Routine posts, minor page edits that pass the gate |
