# 14 — Report Generation Engine

| | |
|---|---|
| **Status** | Approved |
| **Owner** | AI Engineering, Design |
| **Depends on** | 13, 15, 17 |

---

## Universal report contract (FR-503)
Every report and every section answers, in order: **What happened → What changed → Why it matters → What should I do.** Every claim carries its evidence label; every verified claim links to sources.

## Report types

### Baseline Intelligence Report (once, post-onboarding; ≤ 30 min)
A **snapshot**, not a change report — solves cold start. Sections: market overview · competitor overview · technology comparison · pricing comparison · feature comparison · AI adoption · engineering activity · hiring trends · customer sentiment (coverage-labeled) · SWOT per competitor · threat level · opportunity areas · missing features · strategic recommendations. Longitudinal depth comes from Wayback backfill ("Competitor X changed pricing 3× in 12 months") — the report's signature moment.

### Daily CEO Brief (upgraded Daily Digest)
Delivered per user schedule (15). The most engagement-critical artifact in the product — designed to be the first thing a founder reads each morning:

```
Good Morning, <name>.

Yesterday:
✓ OpenAI released new Responses API
✓ Competitor reduced pricing
✓ Two competitors hired ML Engineers
✓ Customer sentiment shifted positive

Today's Recommendation
Prioritize Voice AI integration.

Why: competitor hiring trend + GitHub activity + documentation updates
all point the same direction.                    ← the Reason step, always visible

Market urgency: High
Conviction: High (3 independent signal families)   ← factors enumerated, ADR-011
[ Save as Opportunity ] [ Add to Roadmap ] [ Ignore ] [ Review Later ]
```

Structure: greeting → yesterday's confirmed events (checklist, evidence-labeled) → exactly **one** prioritized Today's Recommendation with reasoning chain, urgency, conviction + factors, and inline decision actions (30) → remaining grouped events → deferred/low items collapsed. Empty day = one honest line, not padding. Review-Later items due today resurface here (FR-1005).

### Weekly Strategic Report
Built for forwarding (persona P2): week's clusters ranked by significance; per-competitor movement; technology-ecosystem shifts affecting the user's stack; 2–4 recommended actions with evidence chains; coverage/health appendix (gaps disclosed — NFR-3.2).

### Monthly Market Report
Trends over weeks: hiring trajectories, pricing evolution, release cadence, sentiment slice trend. Includes "what we said → what happened" retrospective on prior recommendations (trust feature).

### Quarterly Competitive Review
Landscape-level: positioning shifts, SWOT deltas vs. baseline, threat-level changes, strategic themes.

## Generation mechanics
`report_section` tasks (10§3) fill a typed JSON structure stored in `reports.body` (09); renderer (17) is deterministic from that JSON. Export: HTML → PDF (V1). All reports archived and diffable.
