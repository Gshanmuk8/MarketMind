# 15 — Intelligent Notification & Delivery System

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 08§4, 09 (notification_settings, deliveries), 14 |

MarketMind AI never forces users into a fixed schedule. Users have complete control over **when, how, and what** they receive — layered on good defaults so control is optional.

---

## 1. Delivery channels

| Channel | Status |
|---|---|
| Email (Resend free tier) | **MVP** |
| Telegram (Bot API — free) | **MVP** |
| WhatsApp | Future |
| Slack | Future |
| Discord | Future |
| Mobile push | Future |

Multiple channels may be enabled simultaneously. Each channel implements:

```ts
interface DeliveryChannel {
  id: "email" | "telegram" | "whatsapp" | "slack" | "discord" | "push";
  isConfigured(user): boolean;
  render(digest: Digest): ChannelPayload;   // channel-appropriate formatting
  send(payload): Promise<DeliveryResult>;
}
```
Future channels are new implementations only — no core changes (FR-701).

## 2. Custom delivery time — HH:MM precision

- Any time of day: 05:30, 08:00, 11:45, 13:15, 16:30, 21:00, 23:59 — a full time picker, not presets.
- Stored as `send_time (HH:MM)` + `users.tz` (IANA). **All scheduling math: store UTC, convert per-user at evaluation time.** DST is handled by the IANA tz database — a user set to 08:00 Europe/Berlin gets 08:00 wall-clock year-round (ADR-006).
- Dispatcher: hourly tick (08§4) evaluates, each run, which users' local HH:MM falls in the window; enqueues sends. Delivery SLA ±5 min (NFR-4.4).

## 3. Frequency

`daily` · `weekdays only` · `weekly` (chosen weekday) · `monthly` (chosen day, clamped for short months) · `instant alerts for critical events only`. Fully custom cron-like schedules: future enhancement (25).

## 4. Notification preferences — per-topic toggles (`category_prefs` jsonb)

**Competitor Intelligence:** new feature launches · pricing changes · product updates · marketing campaigns · new partnerships · funding announcements · acquisitions.
**Technology Intelligence:** per-provider toggles — OpenAI · Gemini · Claude · Groq · Cerebras · OpenRouter · DeepSeek · Mistral · Llama · xAI (list maintained in 27).
**Engineering Intelligence:** GitHub releases · new repositories · major commits · framework migrations · API changes · SDK releases.
**Hiring Intelligence:** AI engineer · backend · frontend · product · leadership hiring.
**Customer Intelligence:** negative sentiment spikes · positive trends · top feature requests · new reviews (coverage-labeled).

Suppressed items are recorded as `suppressed_pref` in `deliveries` (auditable, reversible).

## 5. Priority floor

`Critical only` · `High + Critical` · `Medium and above` · `Everything`. Applied after preferences; significance comes from 13's rubric.

## 6. Smart Digest — delivered as the Daily CEO Brief (FR-706, 14)

Never 50 separate notifications. The `digest` task (10§3) groups related events into one delivery:

```
Morning Intelligence Report — Today's Summary
• 3 competitors released new features
• 2 pricing changes detected
• OpenAI announced a new API
• Gemini updated model pricing
• One competitor hired 5 AI engineers

AI Strategic Summary
The market is accelerating investment in AI agents. Two direct competitors are
expanding their AI engineering teams. Consider prioritizing agent capabilities
in your roadmap during the next sprint.
```
Instant-critical alerts bypass grouping but still deduplicate within a 30-min window.

## 7. Snooze & Quiet Hours

- **Quiet hours** (e.g., 22:00–07:00 local): non-critical sends are shifted to quiet-hours end, not dropped (`suppressed_quiet` → rescheduled).
- **Weekend pause** · **Vacation mode** (until date) · **Temporary snooze** (hours/days).
- **Critical override:** critical alerts may break quiet hours **only if** the user enables `critical_overrides_quiet` (default off).

## 8. Anti-spam invariants
Max 1 scheduled digest per frequency period per channel; instant alerts rate-limited (≤ 3/day, excess folds into next digest); every send audited in `deliveries`; one-click per-channel disable in every message footer.
