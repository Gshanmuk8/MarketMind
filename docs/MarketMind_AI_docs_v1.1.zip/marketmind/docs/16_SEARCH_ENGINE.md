# 16 — Search Engine (Conversational Analyst)

| | |
|---|---|
| **Status** | Approved |
| **Owner** | AI Engineering |
| **Depends on** | 09, 10, 13 |

---

## Behavior contract
Search behaves like talking to a senior product strategist, answering over **collected evidence** — not open web guessing. Supported intents:

| Intent | Example | Handling |
|---|---|---|
| Entity analysis | "Analyze Notion." | If tracked: synthesize stored profile + signals + insights. If untracked: one-off understanding run within quota, clearly labeled "one-time analysis, not monitored." |
| Comparison | "Compare us with Linear." | Side-by-side over pricing/features/tech/hiring evidence; gaps stated, not filled. |
| Temporal | "What pricing changes happened this month?" | SQL-backed retrieval over `signals` (category=page_diff, price tokens) → summarized with citations. |
| Timeline | "Show me everything that happened during the last 6 months." | Renders the Market Timeline view (FR-1102), month-grouped, filter chips pre-applied. |
| Trend | "What technologies are competitors adopting?" / "What AI models are becoming popular?" | Aggregation over engineering + tech-ecosystem signals. |

## Mechanics (V1 — deliberately simple)
1. **Intent + entity parse** (small model call).
2. **Retrieval:** structured SQL first (signals/insights are already normalized — most questions are queries, not vector search); Postgres FTS (`tsvector`) over payload text for the rest. pgvector is a V2 upgrade, noted in 25 — not needed for MVP scale.
3. **Synthesis:** `search_answer` task; every claim labeled; verified claims cite signal sources; insufficient evidence stated plainly.

## Guardrails
- Answers never exceed the evidence: no fabricated metrics, no invented sources (10§6).
- Untracked-entity analyses consume the shared discovery/search quota (ADR-005) and say so if quota is exhausted ("try after 00:00 UTC").
- Every answer offers "add to monitoring" when the entity isn't tracked.
