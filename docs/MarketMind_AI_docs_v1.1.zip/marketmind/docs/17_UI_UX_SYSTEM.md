# 17 — UI / UX System

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Design |
| **Depends on** | 07, 13, 18 |

---

## Design stance — a command center, not an admin dashboard
**Bloomberg Terminal meets Linear.** One dense, keyboard-driven workspace — not stacked cards. Calm, editorial, text-first typography carries the judgment; information density is earned through hierarchy, not chrome. Concretely:
- **⌘K command palette** is the primary navigation ("compare with Linear", "timeline last 6 months", "open decisions inbox").
- **Three-pane workspace** on desktop: navigation rail · primary stream (Today / Timeline / competitor) · context pane (evidence, reasoning chain, decision actions) — the context pane replaces modal-hopping.
- Card grids are banned as a default layout; lists, tables, and timelines with strong typographic rhythm instead.
- Charts appear only where a trend *is* the point (hiring over time, release cadence).

## The evidence-label visual language (FR-801 — the core UI invariant)

| Label | Treatment |
|---|---|
| **Verified** | Solid badge, strong ink, source-count chip; click → sources + timestamps (≤ 1 interaction, FR-802) |
| **AI Inference** | Outlined badge, muted tone, "inferred" prefix; hover explains basis |
| **Recommendation** | Distinct accent block, always visually downstream of its evidence; advisory phrasing enforced ("Consider…", never "Do…") |

An inference must never carry the visual weight of a verified fact — reviewed in every design PR.

## Onboarding: watching the AI work
The understanding/discovery run streams its reasoning like Perplexity/ChatGPT — a live step sequence, not a spinner:

```
Reading your website…            ✓
Understanding your business…     ✓  (profile fields appear as extracted)
Finding competitors…             ●  "found 4 candidates via comparison pages"
Analyzing market…
Generating SWOT…
Preparing your baseline report…
```
Each step surfaces a one-line genuine artifact of what was found (never fake progress). People trust — and enjoy — watching the analyst think; the stream doubles as the first demonstration of the evidence-first culture.

## Key screens
- **Today:** the CEO Brief rendered as the lead block (greeting, yesterday checklist, one prioritized recommendation with reasoning chain + conviction factors + inline `<DecisionBar>`); grouped insight stream below. Every insight expands to its reasoning chain (Signal → Impact → Reason → Recommendation) and raw Evidence. Feedback 👍/👎 everywhere.
- **Timeline:** month-grouped vertical chronology of the whole market; filter chips (competitor / category / significance / range); backfilled events marked with an archive glyph; any entry opens in the context pane; reachable from Search ("last 6 months") and ⌘K.
- **Decisions:** Inbox (ranked by significance × conviction), Opportunities, Roadmap-lite three-column board, Decision log — provenance one click away on every card.
- **Competitor page:** profile header; vertical timeline of insights; category tabs (Pricing / Hiring / Product / Engineering / News / Sentiment) each with coverage badge; SWOT panel labeled `inference`.
- **Compare:** two-column table; rows only where evidence exists on both sides; gaps say "no compliant public signal."
- **Reports:** rendered from typed JSON (14); print/PDF-clean stylesheet.
- **Search:** single input; streamed answer with inline labels/citations; suggested follow-ups.
- **Settings → Notifications:** channel cards, HH:MM picker with tz shown, frequency, per-topic toggle groups (15§4), priority floor, quiet-hours range slider, weekend/vacation/snooze, critical-override switch.
- **Settings → Data & sources:** allow-list view, per-source health (green/gap/blocked), and **locked paid-provider slots** displayed honestly ("Firmographics — requires data partner").

## States that must be designed (not defaulted)
Empty-with-reason (coverage gap), quota-deferred ("interpretation queued — free-tier quota resets 00:00 UTC"), collection-blocked, insufficient-evidence, vacation-mode banner.

## Accessibility
WCAG 2.1 AA; labels never color-only (badge shape + text); full keyboard nav; reduced-motion respected.
