# 18 — Design System

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Design |
| **Depends on** | 17 |

---

## Tokens

```css
:root {
  /* Ink & surface (light) */
  --mm-ink: #16212e;        --mm-ink-muted: #5b6773;
  --mm-surface: #ffffff;    --mm-surface-alt: #f5f7f9;
  --mm-border: #e3e8ee;

  /* Brand */
  --mm-accent: #0e5a8a;     --mm-accent-soft: #e8f1f7;

  /* Evidence labels (the semantic core) */
  --mm-verified: #1e6b3a;   --mm-verified-bg: #e9f5ee;
  --mm-inference: #6b5d1e;  --mm-inference-bg: #f7f3e3;
  --mm-recommend: #4a2e8a;  --mm-recommend-bg: #efe9f9;

  /* Significance */
  --mm-critical: #a3241a;   --mm-high: #b8641a;
  --mm-medium: #0e5a8a;     --mm-low: #5b6773;

  /* Type */
  --mm-font-ui: Inter, system-ui, sans-serif;
  --mm-font-mono: "JetBrains Mono", ui-monospace, monospace;

  /* Scale (rem): 12 13.5 15 17 20 24 30 38 */
  --mm-radius: 8px;  --mm-radius-lg: 12px;
  --mm-space: 4px;   /* 4-pt spacing system: 4/8/12/16/24/32/48 */
}
```
Dark theme: inverted ink/surface pairs; evidence hues keep ≥ 4.5:1 contrast on both themes.

## Rules
1. Evidence-label colors are **reserved** — never reused decoratively.
2. Significance is a dot/left-border, not a filled card (calm > alarm; critical is the only saturated treatment).
3. One accent. No gradients in product UI. Charts use ink + accent + evidence hues only.
4. Type hierarchy carries structure: reports use the 20/17/15 sizes with generous leading (1.55) — dashboards must read like well-set documents.
5. Motion: 150–200ms ease-out, opacity/transform only.
