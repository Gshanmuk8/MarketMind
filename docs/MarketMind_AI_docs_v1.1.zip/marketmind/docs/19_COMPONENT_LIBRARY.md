# 19 — Component Library

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Frontend |
| **Depends on** | 17, 18 |

Stack: React + TypeScript, Tailwind mapped to 18's tokens, Radix primitives for a11y. Storybook is the contract; every component ships with states + a11y notes.

---

## Semantic components (product-specific)
- `<EvidenceBadge label="verified|inference|recommendation" sources={n} />` — the most important component in the product; encodes 17's visual language; click opens `<SourcePopover>`.
- `<InsightCard>` — title, so-what, EvidenceBadge, SignificanceDot, feedback buttons, Evidence expander.
- `<StrategicSummary>` — the digest's lead paragraph treatment.
- `<CoverageBadge state="full|partial|narrow|gap|blocked" reason />`
- `<CompetitorTimeline>` / `<CompareTable>` (renders only both-sided evidence rows).
- `<ReportRenderer body={ReportJSON}>` — deterministic renderer for 14's typed sections.
- `<ProviderSlot configured={bool}>` — honest locked-slot card for paid providers.
- `<HealthIndicator>` — per-source collection health.
- `<DecisionBar>` — the six decision actions (GitHub export rendered disabled); one-click, optimistic (30§1).
- `<ReasoningChain>` — Signal → Impact → Reason → Recommendation, rendered as a vertical chain with evidence labels per step (FR-406).
- `<ConvictionMeter score factors[]>` — number + enumerated supporting signal families; never shown without factors (ADR-011).
- `<MarketTimeline>` — month-grouped chronology; virtualized; archive-glyph for backfilled events.
- `<RoadmapBoard>` — Considering / Planned / Building, drag between stages.
- `<CommandPalette>` (⌘K) — navigation + query launcher.
- `<ThinkingStream>` — onboarding live-step renderer (17).

## Notification-settings components
- `<TimePicker24 value="HH:MM" tzLabel />` (full 24h precision, FR-702)
- `<FrequencySelect>` · `<TopicToggleGroup categories={15§4}>` · `<PriorityFloor>` 
- `<QuietHoursRange>` · `<PauseControls weekend vacation snooze>` · `<CriticalOverrideSwitch>`
- `<ChannelCard channel state>` (connect/test/disable; Telegram shows bot-link flow)

## Primitives
Button, Input, Select, Switch, Tabs, Dialog, Popover, Tooltip, Toast, Skeleton, EmptyState(reason), Table, Badge, Card — all consuming tokens only; no hard-coded colors (lint-enforced, 26).
