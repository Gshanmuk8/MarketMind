# 20 — API Specification

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 09, 05 |

Internal REST API (app ↔ backend). JSON; auth via session (Supabase Auth JWT); all responses carry evidence labeling — the schema enforces the trust contract.

---

## Conventions
- Base: `/api/v1` · Errors: `{ "error": { "code", "message" } }` · Pagination: `?cursor=&limit=` · Timestamps: ISO-8601 UTC.

## Endpoints

```
POST /companies                      { url }                → 202 { company_id, understanding_job }
GET  /companies/:id                                          → profile (+ coverage summary)
PATCH /companies/:id/profile         { field edits }         → updated profile (FR-104)

GET  /companies/:id/competitors                              → suggested/accepted/rejected lists
POST /companies/:id/competitors      { url }                 → manual add (runs understanding)
PATCH /competitors/:id               { status: accepted|rejected }

GET  /companies/:id/insights         ?significance=&category=&cursor=
GET  /insights/:id                                           → full insight + signal provenance
POST /insights/:id/feedback          { verdict: useful|didnt_matter }
GET  /insights/:id/evidence                                  → signals[] with source_url, observed_at (FR-802)

GET  /companies/:id/reports          ?type=
GET  /reports/:id                                            → typed body JSON
GET  /reports/:id/export             ?format=pdf

POST /search                         { q }                   → { answer_blocks[]: {text, label, signal_ids[]} }

GET  /me/notification-settings
PUT  /me/notification-settings       { channels, send_time:"HH:MM", frequency,
                                       weekly_day?, monthly_day?, priority_floor,
                                       category_prefs, quiet_hours?, weekend_pause,
                                       vacation_until?, snooze_until?,
                                       critical_overrides_quiet }
POST /me/channels/telegram/link                              → { deep_link }   (bot linking)
POST /me/channels/:id/test                                   → sends test digest

POST /insights/:id/decisions         { action, stage?, review_at?, reason? }
GET  /companies/:id/decisions        ?action=&stage=&cursor=
PATCH /decisions/:id                 { stage | brief | review_at }
GET  /companies/:id/decisions/log
GET  /companies/:id/timeline         ?competitor=&category=&from=&to=&cursor=

GET  /companies/:id/health                                   → per-source collection health (NFR-3)
```

## Response invariants
1. Any text block that makes a claim carries `label: verified|inference|recommendation`.
2. `verified` blocks include non-empty `signal_ids`.
3. Coverage-limited categories include `coverage: full|partial|narrow|gap` in list responses.

Machine-readable OpenAPI 3.1 file lives at `/api/openapi.json` and is generated from route schemas (single source of truth; drift fails CI — 24).
