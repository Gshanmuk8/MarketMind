# 21 — Security & Compliance

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 06, 12 |

---

## 1. Collection compliance (the product's defining security posture)
- **Allow-list first:** only domains/endpoints cataloged in 27 are fetchable. Adding a source = PR updating 27 with a legal-basis row.
- **robots.txt enforced in code** (cached 24h, fail-closed on parse errors), identifying User-Agent `MarketMindBot/1.0 (+contact URL)`, per-domain rate limits, no login/paywall/CAPTCHA circumvention — ever (Manifesto belief 5; NFR-2).
- 403/429 → backoff → `blocked` state; we never rotate IPs/UAs to evade blocks.
- Every fetch decision logged (`collection_health`) — auditable compliance, not asserted compliance.

## 2. Application security
- Auth: Supabase Auth (magic link, GitHub OAuth); short-lived JWTs; RLS on every user-scoped table (09).
- Secrets: platform secret stores (Vercel/GitHub Actions encrypted secrets); none in repo; quarterly rotation.
- Input handling: fetched web content is untrusted — sanitized before storage, escaped on render, and **treated as data, not instructions, in prompts** (prompt-injection defense: LLM tasks wrap scraped text in delimited data blocks; instructions live only in versioned templates; outputs schema-validated — 10§4).
- Standard headers: CSP, HSTS, X-Content-Type-Options; CSRF on state-changing routes.

## 3. Data protection & privacy
- Personal data held: email, tz, preferences, company profile. Export + delete on request (full cascade).
- Collected signals are public-web observations of companies; no personal-data enrichment of individuals (hiring signals aggregate roles, never named candidates/employees).
- Telegram linking uses one-time deep-link tokens; chat IDs stored hashed.

## 4. LLM-specific
- Free-tier providers receive only public collected text + the user's own public profile — never credentials or other users' data.
- Per-task output validators reject label violations (an unverifiable "verified" claim is a security bug, not a quality bug).

## 5. Threat notes (V1-proportional)
No multi-tenant orgs yet → the main risks are scraped-content injection (mitigated above), SSRF via user-supplied URLs (fetch layer blocks private IP ranges/localhost/link-local; DNS-rebinding check), and quota abuse (per-user onboarding quotas).
