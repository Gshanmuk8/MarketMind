# 22 — Performance & Observability

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 06 |

---

## Budgets (free-tier realistic)
| Surface | Budget |
|---|---|
| Dashboard p95 TTI | ≤ 2.5 s |
| Insight/report page p95 | ≤ 1.5 s (server-rendered from stored JSON) |
| Search answer first token | ≤ 4 s; complete ≤ 15 s |
| Onboarding: profile ready | ≤ 2 min |
| Baseline report | ≤ 30 min |
| Notification delivery | scheduled HH:MM ± 5 min |
| Full collection run (10 competitors) | ≤ 25 min within Actions limits |

## Principles
1. **Precompute, don't compute on request.** Reports and digests are generated in the collection plane and stored; the interactive plane renders stored JSON. LLM calls never happen inside a page request (except Search, which streams).
2. **Quota is a performance dimension.** The budgeter (10§2) is instrumented like latency: quota-used, deferrals, cache-hit-rate are first-class metrics.
3. **DB discipline:** indexed access paths listed in 09; no unbounded scans; payload caps keep rows small.

## Observability (free-tier)
- `collection_health` is the primary ops surface (per-source status, latency, items, gaps) — rendered in Settings → Data & sources and in the weekly report appendix.
- GitHub Actions run logs = collection audit trail (public, reviewable — a portfolio feature).
- Web vitals via hosting platform analytics (free tier).
- Weekly automated summary: success rate per category, LLM cache-hit %, deferral count, delivery SLA hits — posted as a repo issue.

## Alerting (V1-proportional)
Actions job failure → GitHub notification + issue. Two consecutive `blocked`/`gap` states on the same source → flagged in next digest's health appendix (churn-vs-gap metric, 01§7).
