# 23 — Deployment & Environments

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 08 |

---

## Reference free-tier stack (verify limits at build time; swaps allowed within ADR-003's interfaces)

| Layer | Choice | Free-tier note |
|---|---|---|
| Web app | Vercel Hobby (or Cloudflare Pages) | Serverless; short function ceilings → no jobs in requests |
| DB + Auth | Supabase free (or Neon + Auth.js) | ~0.5 GB Postgres, RLS, Auth included |
| Scheduler / jobs | GitHub Actions cron (public repo) | Free minutes; runs are auditable logs |
| LLM | Gemini free API + Groq free | Behind InterpretationProvider; keys in Actions secrets |
| Email | Resend free | Thousands/month — far beyond MVP needs |
| Telegram | Bot API | Free |
| Object storage (latest raw snapshots) | Supabase Storage free | Optional; DB-only is acceptable at MVP scale |

## Environments
- **prod** — main branch. **preview** — per-PR (Vercel previews) against a branch DB (Neon branching / Supabase preview). No long-lived staging in V1.

## Pipeline (GitHub Actions)
1. `ci.yml` — lint, typecheck, unit + contract tests (24), OpenAPI drift check, migration dry-run.
2. `deploy` — Vercel auto-deploy on main after CI green; migrations applied via `migrate` job first (expand-and-contract pattern; never destructive in the same release).
3. `collect.yml` — cron `0 3,15 * * *` (2×/day) full collection→analysis→report pipeline.
4. `dispatch.yml` — cron hourly: notification dispatcher + retries + critical evaluation.

## Configuration
Twelve-factor: all provider keys via env. **Absent key = provider not configured = graceful degradation** (FR-901) — deploys never fail because a paid key is missing.

## Rollback
Vercel instant rollback for the app; DB migrations reversible or gated; collection plane is stateless per run — a bad run is re-run after fix, signals are idempotent by content-hash.
