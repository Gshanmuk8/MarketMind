# 24 — Testing Strategy

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |
| **Depends on** | 05 (FR IDs), 10, 12 |

Tests reference FR/NFR IDs. CI green is the merge gate (23).

---

## Layers

1. **Unit** — diff extraction, price-token parsing, hash/dedupe, tz/DST conversion (property-based tests around DST transitions — FR-702 is where scheduling bugs live), significance rubric mapping, quota budgeter.
2. **Collector contract tests** — each `SignalProvider` runs against **recorded fixtures** (saved HTML/JSON responses, refreshed deliberately, never live-fetched in CI): asserts normalized `Signal` shape, hash stability, robots/allow-list refusal paths, blocked-state handling. Fixtures include Greenhouse/Lever/Ashby board payloads, RSS variants, Wayback CDX responses, GitHub API pages.
3. **Compliance tests (fail-closed)** — fetch layer refuses: non-allow-listed domain, robots-disallowed path, private-IP/SSRF targets, missing UA. These are security tests (21) and block merge.
4. **AI-layer tests** —
   - *Schema/validator tests:* every task's output validated; `verified`-without-sources rejected; `insufficient_evidence` path covered.
   - *Golden-set evals:* ~30 curated signal fixtures with expected significance level and label; run on every prompt-template change; regression threshold enforced. (Prompts are versioned code — they get tests like code.)
   - *Injection suite:* scraped-content fixtures containing adversarial instructions must not alter output structure (21§2).
5. **API contract tests** — responses validated against OpenAPI; label invariants (20 §invariants) asserted on every claim-bearing endpoint.
6. **E2E (Playwright)** — the release-criteria journeys (02§4): onboard→confirm competitors; view baseline; configure notifications (HH:MM + quiet hours); receive test digest; evidence-click ≤ 1 interaction.
7. **Scheduled-pipeline smoke** — a nightly Actions run against 2 fixture companies end-to-end, writing to a test DB; failure opens an issue.

## Coverage stance
No vanity % target. Required: every FR has ≥ 1 mapped test; compliance suite exhaustive; AI golden set current with prompts.
