# 25 — Roadmap

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Product |
| **Depends on** | 02, 29 |

---

## V1 — MVP (6-week build)
| Week | Milestone (exit criterion) |
|---|---|
| 1 | Skeleton + compliance fetch layer + schema (fetch refusal paths tested) |
| 2 | PageDiff collector + Wayback backfill (queryable historical changes for 5 real companies) |
| 3 | Hiring (ATS) + Content collectors (hiring-over-time series per competitor) |
| 4 | Analysis engine on free-LLM cascade (3–7 labeled insights from a week of signals) |
| 5 | Understanding + Discovery + onboarding UX (URL→confirmed set < 10 min) |
| 6 | Baseline report, CEO Brief + digests, Email+Telegram at HH:MM, Decision Workspace (actions, Inbox, Roadmap-lite, log), Market Timeline, demo + coverage post-mortem |

## V1.x — hardening (post-demo)
GitHub + News + TechEcosystem collectors fully wired to preferences; monthly/quarterly reports; export polish; feedback-threshold tuning live.

## The V1 discipline (binding)
A finished, polished V1 beats an unfinished platform with 100 planned features. V1 completeness is defined by 02§4 release criteria — onboarding, competitor discovery, the intelligence workspace, the CEO Brief, and the Decision Workspace, all polished. Nothing enters V1 scope after Week 2 without removing something of equal size (ADR-012).

## V2 — after validated interest
Paid provider slots activated (Crunchbase funding, firmographics, licensed reviews, tech-stack API); **GitHub Issues export from the Decision Workspace**; **Personal Intelligence ranking** (digest/Brief reordering learned from decision + feedback stream — 13§5); Slack + Discord + WhatsApp channels; team seats + shared workspaces (P2 monetization per Vision review); pgvector search; custom cron-like schedules; report white-labeling.

## V3 — analyst maturity
Feedback-trained significance models per segment; per-founder attention models (full Personal Intelligence); Jira/Linear export; multi-language monitoring; "what we said vs. what happened" auto-retrospectives expanded; customer-facing API; mobile push; CRM/Slack workflow integrations.

## Explicit never (Manifesto)
Autonomous actions on the user's behalf; authenticated/paywalled collection; reselling collected data.
