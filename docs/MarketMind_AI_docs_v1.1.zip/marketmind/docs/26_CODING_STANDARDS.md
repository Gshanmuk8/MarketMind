# 26 — Coding Standards

| | |
|---|---|
| **Status** | Approved |
| **Owner** | Engineering |

---

## Stack & style
- TypeScript strict everywhere (app + jobs). Python permitted only in isolated analysis scripts if justified by an ADR.
- ESLint + Prettier, enforced in CI; no warnings on main.
- Naming: `SignalProvider` implementations `<Source><Category>Provider`; LLM task templates `tasks/<task_name>@v<N>.md`.

## Architecture rules (lint-enforced where possible)
1. **Interfaces at the boundaries:** collectors, interpretation, delivery channels — implementations never imported directly outside their registry (ADR-003).
2. **No LLM/network calls in the interactive plane** except Search (22§1). 
3. **No hard-coded colors/spacing** in components — tokens only (18).
4. **Evidence labels are types**, not strings scattered: `type EvidenceLabel = "verified" | "inference" | "recommendation"` — single source in `core/types`.
5. Untrusted scraped text is typed `UntrustedText` and cannot enter a prompt template except through the delimiting wrapper (21§2).

## Process
- Trunk-based; PRs small; every behavior change updates the matching doc **in the same PR** (NFR-7.3) and references FR/ADR IDs in the description.
- Migrations: expand-and-contract; reviewed like code.
- Commits: Conventional Commits.
- Prompts, fixtures, and golden sets live in-repo and are reviewed like code (24§4).

## Documentation of record
`/docs` (this set) is authoritative. Code comments explain *why*, not *what*. Any decision that would surprise a future maintainer becomes an ADR in 28.
