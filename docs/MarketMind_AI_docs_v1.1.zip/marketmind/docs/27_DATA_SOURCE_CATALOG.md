# 27 — Data Source Catalog

| | |
|---|---|
| **Status** | Approved — **authoritative allow-list** (21§1). Adding a source = PR to this file with legal-basis row. |
| **Owner** | Engineering |
| **Depends on** | 12, 21 |

Legend — Refresh: per collection run (2×/day) unless noted. Legal basis reviewed at add time; free-tier limits verified at build time (they change).

---

## Category: Website / product / pricing (grade A)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| Competitor public pages (home, pricing, product, changelog) | Content diffs, price tokens | Free | 2×/day | robots.txt enforced; public non-authenticated only; polite rate limits; identifying UA |
| sitemap.xml | Watchable-page discovery | Free | Weekly | Published for crawling by definition; robots still checked |
| **Wayback Machine CDX API** | Historical snapshots (backfill) | Free | Once per competitor-add | Public archive API; attribution in evidence view; ≤ 12 snapshots/page cap |

## Category: Hiring (grade A)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| Greenhouse public board API (`boards.greenhouse.io/v1/boards/{slug}/jobs`) | Structured postings | Free | 2×/day | Public, unauthenticated, documented for public consumption |
| Lever postings API (`api.lever.co/v0/postings/{slug}`) | Structured postings | Free | 2×/day | Same |
| Ashby public job board JSON | Structured postings | Free | 2×/day | Same |
| Company careers pages | Fallback diffs | Free | 2×/day | robots.txt enforced |
| ❌ Job-board aggregators (LinkedIn/Indeed etc.) | — | — | — | **Excluded:** ToS prohibits scraping |

## Category: Content (grade A)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| Blog/changelog RSS/Atom | Posts, releases, cadence | Free | 2×/day | Feeds are published for syndication; excerpts stored, full text linked |

## Category: Engineering (grade B)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| GitHub REST API (token) | Releases, repos, stars/forks, public dependency files | Free (5k req/hr) | 2×/day | API ToS-compliant; public repos only |

## Category: Business / funding (grade B — labeled *partial coverage*)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| Google News RSS | Press mentions, announcements | Free | 2×/day | Headlines/links + snippets; full articles linked, not stored (copyright) |
| Competitor press/newsroom pages | Official announcements | Free | 2×/day | robots enforced |
| SEC EDGAR full-text search | US filings (Form D, S-1…) | Free | Daily | Public government data; fair-access rate limits respected |
| 🔒 Crunchbase API | Structured funding | **Paid slot (V2)** | — | Licensed; `FundingProvider(paid)` stub in V1 |

## Category: Technology ecosystem (grade A — global shared targets)
| Source | Provides | Cost | Refresh |
|---|---|---|---|
| Official blogs/changelogs/status feeds: OpenAI, Google (Gemini), Anthropic (Claude), Groq, Cerebras, OpenRouter, DeepSeek, Mistral, Meta (Llama), xAI, Perplexity | Models, pricing, context windows, SDK/API/MCP changes, deprecations | Free | 2×/day |
Legal: official first-party publications; robots enforced; collected once, shared across all users.

## Category: Customer sentiment (grade C — labeled *narrow slice*)
| Source | Provides | Cost | Refresh | Legal considerations |
|---|---|---|---|---|
| Hacker News (Algolia API) | Mentions, discussion sentiment | Free | 2×/day | Fully open public API |
| Reddit API (free tier) | Subreddit mentions | Free (rate-limited) | Daily | Within free-tier non-commercial terms — **re-verify terms at build time and before any commercial launch** |
| ❌ G2 / Capterra | — | — | — | **Excluded:** ToS prohibits scraping; `ReviewSignalProvider` paid/licensed slot only |

## Category: Firmographics (grade D)
| Source | Status |
|---|---|
| 🔒 Apollo/Clearbit-class APIs | **Excluded from V1** — no compliant free source; visible locked slot; outputs would be labeled third-party-sourced |

## Search assist (discovery only)
| Source | Provides | Cost | Legal |
|---|---|---|---|
| Google Programmable Search JSON API | Discovery queries | Free — 100 queries/day | Official API; quota budgeting per ADR-005 |
| ❌ Scraping search engines directly | — | — | Excluded (ToS) |
