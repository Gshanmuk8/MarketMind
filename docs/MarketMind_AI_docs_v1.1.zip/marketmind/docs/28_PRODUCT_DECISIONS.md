# 28 — Product Decisions (ADR Log)

| | |
|---|---|
| **Status** | Living document — append-only |
| **Owner** | Product + Architecture |

Format: Context → Decision → Consequences. Future changes must be consistent with these or supersede them explicitly.

---

## ADR-001 — Wayback backfill is a day-one requirement, not a nice-to-have
**Context:** Cold start: a change-detection product has nothing to say in week one; the Vision review identified longitudinal history as the product's only compounding asset.
**Decision:** Backfill up to 24 months of pricing/home snapshots via the Wayback CDX API at competitor-add; the Baseline Report leads with longitudinal facts.
**Consequences:** Day-one value; the moat asset starts accruing immediately; `backfilled` flag distinguishes archive-derived evidence in the UI.

## ADR-002 — Recommendations are grounded in public knowledge of both sides only
**Context:** Truly personalized advice ("discount your at-risk accounts") requires private context the system doesn't have; faking it is the fastest trust-killer. Zero-effort onboarding forbids questionnaires.
**Decision:** The user's own site is ingested through the identical collection pipeline; all recommendations condition on public profiles of both sides. Deeper context is earned later via optional, per-insight micro-questions (V2), never demanded upfront.
**Consequences:** Honest, defensible recommendations; Moment-4 scope is narrower but real; symmetric pipeline reuse simplifies architecture.

## ADR-003 — Provider interfaces per signal category; configuration-driven registration
**Context:** MVP constraint: paid APIs must be addable later without refactoring; graceful degradation must be real, not an untested branch.
**Decision:** One interface per category (and for LLMs and delivery channels); a provider activates iff its env key exists; absent → free provider → explicit coverage gap. Degradation is thus the daily default path.
**Consequences:** Zero-code paid upgrades; honest locked slots in UI; slight up-front abstraction cost accepted.

## ADR-004 — Evidence buckets in UI; no numeric confidence
**Context:** LLM numeric confidence is poorly calibrated; "82% confident" is false precision that ships the exact trust failure the product exists to avoid.
**Decision:** User-facing evidence is three labels (verified / inference / recommendation) plus source counts ("corroborated by 3 sources"). Numeric scores remain internal (discovery ranking, gating).
**Consequences:** Defensible trust surface; simpler UI; internal scores can mature into calibrated ones before ever being exposed.

## ADR-005 — Quota is an architectural input, not an ops concern
**Context:** Free tiers impose RPM/RPD ceilings (LLM) and 100 searches/day (discovery).
**Decision:** Central budgeters for LLM tokens/requests and search queries; batching + content-hash caching mandatory; overflow defers visibly ("queued — quota resets 00:00 UTC"), never drops or degrades silently.
**Consequences:** Predictable behavior at $0; the deferral state is designed UI, not an error.

## ADR-006 — UTC storage, IANA per-user conversion, HH:MM wall-clock semantics
**Context:** Users pick any HH:MM; DST must not shift their 08:00 digest.
**Decision:** Store UTC everywhere; `users.tz` (IANA) converts at dispatch time; hourly dispatcher evaluates wall-clock windows; property-based DST tests required (24§1).
**Consequences:** Correct scheduling year-round; ±5 min SLA achievable on an hourly tick with minute-level enqueue.

## ADR-007 — G2/Capterra and job aggregators excluded; compliance is fail-closed
**Context:** Their ToS prohibit scraping; the Manifesto makes compliance a floor.
**Decision:** Excluded entirely; visible licensed-provider stubs instead; allow-list (27) is the only fetchable surface and is fail-closed in code.
**Consequences:** Narrower sentiment coverage, honestly labeled — coverage honesty is a feature (17), and the exclusion itself demonstrates the product's values.

## ADR-008 — GitHub Actions as the scheduler
**Context:** Free-tier serverless can't run long jobs; the MVP needs a free, reliable, auditable scheduler.
**Decision:** Public-repo Actions cron for collection (2×/day) and dispatch (hourly). Runs double as a public collection audit log.
**Consequences:** $0, transparent, portfolio-visible; cron jitter accepted within the days/weeks product timescale (NFR-8); migration path to a queue service in V2 if validated.

## ADR-009 — Two-plane architecture (interactive vs. collection)
**Context:** Function execution ceilings; precompute-over-compute performance stance (22).
**Decision:** The web app never performs collection/interpretation (Search excepted, streamed); all heavy work runs scheduled and writes stored artifacts.
**Consequences:** Fast pages at $0; clean failure isolation; Search is the one latency-sensitive LLM path and is budgeted separately.

## ADR-010 — Postgres FTS before vectors
**Context:** Signals/insights are already structured; MVP corpus is small.
**Decision:** SQL + tsvector retrieval in V1; pgvector deferred to V2 (25).
**Consequences:** Simpler stack, zero added infra; revisit when corpus or query complexity outgrows FTS.

## ADR-011 — Evidence-derived conviction scores on recommendations (amends ADR-004)
**Context:** Reviewer feedback: score recommendations, not just competitors ("Confidence 93% — because hiring trend, GitHub activity, documentation updates support it"). ADR-004 bans numeric confidence because LLM *self-reported* confidence is uncalibratable.
**Decision:** Recommendations carry a **conviction score computed deterministically from evidence** — the count and agreement of independent supporting signal families — always displayed with those factors enumerated. This is explainable arithmetic over observations, not model self-assessment, so it does not violate ADR-004's rationale; ADR-004 continues to ban *verbalized LLM confidence* everywhere. UI defaults to buckets (High/Medium/Low + factors); the numeric form may be exposed once the weekly audit (10§5) shows the score tracks outcome quality.
**Consequences:** Recommendations become rankable (Decisions Inbox, CEO Brief prioritization) and *more* trustworthy, because the number always arrives with its reasons.

## ADR-012 — Decision Workspace in V1, deliberately lite
**Context:** Reviewer identified the Decision Workspace as the biggest missing feature — without it the loop ends at reading. Same reviewer's strongest advice: finish V1; don't expand endlessly.
**Decision:** V1 ships the six decision actions, Inbox, Opportunities, three-stage Roadmap-lite, and the Decision log — and nothing more. GitHub Issues export, assignees, due dates, comments, and any PM-tool surface are V2+. GitHub export renders as a visible disabled slot (consistent with ADR-003's honest-locked-slot pattern). Zero-sum scope rule: nothing enters V1 after Week 2 without an equal removal.
**Consequences:** The loop closes (read → decide) at small engineering cost (one table, one board, one bar component); the North Star becomes directly measurable; scope pressure has a named gate.

## ADR-013 — Command-center UI; streamed-reasoning onboarding
**Context:** Reviewer: "Bloomberg Terminal meets Linear — one large command center, not cards-cards-cards"; onboarding should show the AI working, like Perplexity/ChatGPT reasoning.
**Decision:** Three-pane keyboard-driven workspace with ⌘K palette as primary navigation; card-grid defaults banned (17). Onboarding streams genuine pipeline steps with real artifacts per step — never fake progress animation.
**Consequences:** Higher UI engineering bar accepted for V1 polish (per ADR-012's finish-V1 discipline); the onboarding stream doubles as the product's first trust demonstration.
