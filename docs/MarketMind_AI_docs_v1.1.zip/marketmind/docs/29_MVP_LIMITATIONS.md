# 29 — MVP Limitations

| | |
|---|---|
| **Status** | Approved — honesty is a feature; this document is user-facing in spirit (mirrored in-app under Settings → Data & sources) |
| **Owner** | Product |

The MVP deliberately does **not** do the following. Each limitation is a decision (28), not an oversight.

---

## Data & coverage
1. **Public signals only.** No authenticated, paywalled, or CAPTCHA-protected content — ever. Anything a logged-out browser can't see, we can't either.
2. **No paid data APIs.** Crunchbase, BuiltWith-class, Apollo/Clearbit-class, licensed review data: visible locked provider slots, not silent dependencies (FR-901).
3. **Funding/business coverage is partial** — free news + EDGAR miss unannounced or non-US events; labeled *partial* in the UI.
4. **Customer sentiment is a narrow slice** — HN + limited Reddit only; **G2/Capterra excluded by their ToS** (ADR-007). Sentiment insights are labeled *narrow coverage* and are inferences, not verified metrics.
5. **No verified firmographics** (employee counts, revenue estimates). The slot exists; the data partner doesn't yet.
6. **Tech-stack detection is passive inference** from public page source only — labeled single-source inference.
7. **English-language, primarily US/global-SaaS competitor sets.** Multi-language monitoring is V3.
8. **Coverage gaps are visible, not hidden.** A blocked or dead source shows as a gap state; "no news" and "couldn't look" are never conflated.

## Intelligence & trust
9. **Every AI conclusion is labeled.** Verified / AI Inference / Reasoned Recommendation — no exceptions. The model's *self-reported* confidence is never shown (ADR-004); recommendations instead carry an evidence-derived conviction with its supporting signal families enumerated (ADR-011), shown as High/Medium/Low buckets until calibration is demonstrated.
10. **Recommendations use public context of both sides only** (ADR-002). The system does not know private revenue, pipeline, or strategy, and never pretends to.
11. **The system may say "insufficient evidence."** It will not fill gaps with plausible text.
12. **Significance thresholds start as heuristics** (13 rubric) tuned by simple feedback — not a trained model (V3).

## Product scope
13. **Timescale is hours-to-days.** Not real-time; no trading/market-sentiment use.
14. **Advisory only.** No autonomous actions on the user's behalf — a permanent non-goal, not an MVP gap.
15. **Channels: Email + Telegram only.** WhatsApp/Slack/Discord/push are future (15§1).
16. **Single-user workspaces.** No teams, roles, or sharing permissions (V2).
17. **Custom cron-like schedules not yet supported** — daily/weekdays/weekly/monthly/instant-critical only (15§3).
17a. **Decision Workspace is deliberately lite** — no GitHub/Jira/Linear export yet (visible disabled slot), no assignees/due dates/comments; it bridges to your PM tools, it doesn't replace them (ADR-012).
17b. **Personal Intelligence is not yet active** — V1 records your decisions and feedback; personalized ranking of Briefs/digests begins in V2 (13§5).
18. **Search answers only from collected evidence** plus one-off quota-bounded analyses; it is not a general web assistant.

## Infrastructure honesty
19. **Free-tier quotas shape behavior:** interpretation can defer to the next run under quota pressure ("queued — resets 00:00 UTC"); discovery search is capped at 100 queries/day shared (ADR-005). Deferral is visible, never silent loss.
20. **Storage discipline:** raw HTML kept only for latest snapshots; history is stored as extracted text + structured diffs (NFR-5.1).
21. **Scheduling tolerance ± 5 min** on an hourly dispatcher (ADR-006/008) — appropriate to the product's timescale.
22. **Built for demonstration and learning first.** Scale hardening (queues, caching layers, SLOs) begins only after user interest is validated — per the MVP constraints in 01§2.
