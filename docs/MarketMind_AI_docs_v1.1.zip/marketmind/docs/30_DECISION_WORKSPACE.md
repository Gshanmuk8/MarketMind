# 30 — Decision Workspace

| | |
|---|---|
| **Status** | Approved (added in Rev. 1.1 — reviewer feedback) |
| **Owner** | Product, Engineering |
| **Depends on** | 13, 14, 17; ADR-012 |

---

## Why this exists

Intelligence that ends at a report is still information. The Manifesto's test — *does this help the founder decide what to build, what to ignore, and what to do next?* — is only fully passed when the product captures the decision itself. The loop therefore extends:

```
Website → Competitors → Signals → AI Analysis → Recommendations
        → Decision Workspace → Roadmap → Execution
```

The product stops being something founders *read* and becomes something that *changes what they do*.

## 1. Decision actions (V1 — on every recommendation and insight)

| Action | Effect |
|---|---|
| **Save as Opportunity** | Creates a Decision record (`opportunity`) linked to the insight + its full evidence chain |
| **Ignore** | Records `ignored` + optional reason; feeds the significance/personalization loop (13§5) — the strongest negative-preference signal available |
| **Create Feature** | Creates a `feature` Decision with an AI-drafted one-paragraph brief (problem, evidence, competitor context) — editable |
| **Add to Roadmap** | Places a Decision into the lightweight Roadmap board (below) |
| **Review Later** | Snoozes to a chosen date; resurfaces in that day's CEO Brief |
| **Export to GitHub Issues** | **Future (V2)** — visible disabled slot, consistent with the locked-provider pattern (ADR-003) |

Buttons render inline on insight cards and inside reports (`<DecisionBar>`, 19). One click, no modal for the simple actions.

## 2. The Workspace views

- **Inbox** — undecided recommendations, ranked by significance × conviction.
- **Opportunities** — saved items with evidence chains; sortable by conviction, recency, competitor.
- **Roadmap (lite)** — three columns: *Considering → Planned → Building*. Deliberately not a project-management tool (Manifesto non-goal: not a CRM/PM suite); it is the bridge from intelligence to the founder's real tools. Each card retains its provenance: decision → insight → signals → sources (FR-802 extended).
- **Decision log** — append-only history: what was decided, when, on what evidence. Powers the "what we said vs. what happened" retrospectives (14) — now extended to "what *you* decided vs. what happened."

## 3. Closing the loop

Decisions are the product's highest-value feedback: `saved/created/roadmapped` ⇒ strong positive weight; `ignored` ⇒ strong negative weight — both feed significance thresholds (13§5) and Personal Intelligence (V2/V3, 25). The post-validation North Star (Weekly **Actioned** Insights, 01§7) is measured directly from this table instead of proxies.

## 4. Schema (adds to 09)

```sql
create table decisions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies not null,
  insight_id uuid references insights not null,
  action text not null check (action in
    ('opportunity','ignored','feature','roadmap','review_later')),
  stage text check (stage in ('considering','planned','building')),  -- roadmap items
  brief text,                       -- AI-drafted, user-edited (Create Feature)
  review_at date,                   -- Review Later
  reason text,                      -- optional, on Ignore
  created_at timestamptz default now()
);
```

## 5. API (adds to 20)

```
POST /insights/:id/decisions      { action, stage?, review_at?, reason? }
GET  /companies/:id/decisions     ?action=&stage=&cursor=
PATCH /decisions/:id              { stage | brief | review_at }
GET  /companies/:id/decisions/log
```

## 6. V1 scope guard (reviewer's advice: finish V1, don't expand endlessly)

V1 ships: the six actions (GitHub export as a disabled slot), Inbox, Opportunities, Roadmap-lite, Decision log. V1 does **not** ship: GitHub/Jira/Linear export, assignees, due dates, comments, or anything that turns this into a PM tool. See ADR-012.
